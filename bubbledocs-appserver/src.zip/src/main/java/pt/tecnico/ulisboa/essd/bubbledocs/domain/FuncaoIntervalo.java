package pt.tecnico.ulisboa.essd.bubbledocs.domain;

import org.jdom2.Element;

public class FuncaoIntervalo extends FuncaoIntervalo_Base {
    
    public FuncaoIntervalo() {
        super();
    }

    public Element exportToXML() {
		return null;
		// TODO Auto-generated method stub
		
	}

	public void importToXML() {
		// TODO Auto-generated method stub
		
	}
}
