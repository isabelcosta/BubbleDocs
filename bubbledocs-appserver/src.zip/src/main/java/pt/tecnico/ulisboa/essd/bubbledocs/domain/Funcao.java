package pt.tecnico.ulisboa.essd.bubbledocs.domain;

import org.jdom2.Element;

public class Funcao extends Funcao_Base {
    
    public Funcao() {
        super();
    }

    public Element exportToXML() {
		return null;
		// TODO Auto-generated method stub
		
	}

	public void importToXML() {
		// TODO Auto-generated method stub
		
	}
}
