package pt.tecnico.ulisboa.essd.bubbledocs;

public class ImportDocumentIntegratorTest extends BubbleDocsServiceTest {

	public ImportDocumentIntegratorTest() {
		// TODO Auto-generated constructor stub
	}

}
